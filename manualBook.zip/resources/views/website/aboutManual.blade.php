<div class="page-title text-center mb-3">About Us</div>
<div class="page-body align-items-center justify-content-center">
    <img src="{{ asset('web-images/'.$logo->logo)}}" width="100" height="100">
    <p>{{$about->about_us}}</p>
</div>
<link rel="stylesheet" href="{{ asset('css/about.css') }}">