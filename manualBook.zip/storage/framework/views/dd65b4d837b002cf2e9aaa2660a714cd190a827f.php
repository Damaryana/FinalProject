<div class="page-title text-center mb-3">Daftar Buku Manual</div>
<div class="page-body">
    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li><a href="/manual/<?php echo e($a->id); ?>"><?php echo e($a->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        Data Kosong
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH F:\Kantor\manualBook\resources\views/website/listManual.blade.php ENDPATH**/ ?>