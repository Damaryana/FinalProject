

<?php $__env->startSection('content'); ?>
<span class="title-page">Sub-Modul(<?php echo e($subPart->name); ?>)</span>

<form action="/admin/sub-part" method="post" class="mb-3 mt-3">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($subPart->id); ?>" name="part_id">
    <input type="text" class="search d-inline w-50" placeholder="Tambah Sub-Modul" name="name">
    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
</form>

<table class="table table-striped w-100">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Sub-Modul</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $subPart->subPart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($sb->id); ?>  </th>
      <td><a href="/admin/item/<?php echo e($sb->id); ?>"><?php echo e($sb->name); ?></a></td>
      <td>
        <button class="btn-success btn-sm">
          <i class="fas fa-edit"></i>
        </button>&nbsp

        <button class="btn-danger btn-sm delete-button">
          <i class="fas fa-trash-alt"></i>
        </button>

        <div class="trash">
          <form action="/delete/sub-part/<?php echo e($sb->id); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <label for="">Apakah anda yakin akan menghapus ini?</label>
            <button type="submit" class="btn-sm btn-danger">Hapus</button>
            <button type="button" class="btn-sm btn-primary cancel">Batal</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <td colspan="3" class="text-center">Data Kosong</td>
    <?php endif; ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kantor\manualBook\resources\views/inputSubPart.blade.php ENDPATH**/ ?>