

<?php $__env->startSection('content'); ?>
<span class="title-page">Item(<?php echo e($item->name); ?>)</span>

<form action="/admin/item" method="post" class="mb-3 mt-3">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($item->id); ?>" name="sub_part_id">
    <div class="input-textarea w-75">
        Jika ingin membuat sebuah "Teks Prosedur", awali dengan simbol <i>petik tiga</i>(<strong>'''</strong>) 
        dan akhiri dengan <i>petik tiga</i>(<strong>'''</strong>). Untuk setiap langkahnya akhiri dengan tanda <i>petik koma</i>(<strong>;</strong>) 
        <textarea name="section" class="text-area w-100" rows="10"></textarea>
    </div>
    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
</form>

<table class="table table-striped w-100">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Item</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $item->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($i->id); ?>  </th>
      <td><?php echo e(substr($i->section, 0, 5)); ?></td>
      <td>
        <button class="btn-success btn-sm">
          <i class="fas fa-edit"></i>
        </button>&nbsp

        <button class="btn-danger btn-sm delete-button">
          <i class="fas fa-trash-alt"></i>
        </button>

        <div class="trash">
          <form action="/delete/sub-part/<?php echo e($i->id); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <label for="">Apakah anda yakin akan menghapus ini?</label>
            <button type="submit" class="btn-sm btn-danger">Hapus</button>
            <button type="button" class="btn-sm btn-primary cancel">Batal</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <td colspan="3" class="text-center">Data Kosong</td>
    <?php endif; ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kantor\manualBook\resources\views/inputItem.blade.php ENDPATH**/ ?>