<div class="page-title text-center mb-3">About Us</div>
<div class="page-body align-items-center justify-content-center">
    <img src="<?php echo e(asset('web-images/'.$logo->logo)); ?>" width="100" height="100">
    <p><?php echo e($about->about_us); ?></p>
</div>
<link rel="stylesheet" href="<?php echo e(asset('css/about.css')); ?>"><?php /**PATH F:\Kantor\manualBook\resources\views/website/aboutManual.blade.php ENDPATH**/ ?>