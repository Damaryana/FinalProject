

<?php $__env->startSection('content'); ?>
<form action="/upload-logo" method="post" class="mb-3 mt-3" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label for="logo">Logo</label>
    <input type="file" name="logo" id="logo">
    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
</form>

<form action="/upload-about" method="post" class="mb-3 mt-3" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <textarea name="about" cols="100" rows="10">Tentang Buku Manual</textarea>
    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kantor\manualBook\resources\views/admin/website.blade.php ENDPATH**/ ?>