

<?php $__env->startSection('content'); ?>
<span class="title-page">Team</span>

<form action="/team" method="post" class="mb-3 mt-3" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="text" class="search mb-3" placeholder="Nama" name="name">
    <input type="text" class="search mb-3" placeholder="Nim" name="nim">
    <input type="text" class="search mb-3" placeholder="Peran" name="role">
    <input type="file" name="image">
    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
</form>

<table class="table table-striped w-100">
  <thead>
    <tr>
      <th scope="col">Nama</th>
      <th scope="col">Nim</th>
      <th scope="col">Role</th>
      <th scope="col">Gambar</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($t->name); ?></th>
      <td><?php echo e($t->nim); ?></td>
      <td><?php echo e($t->role); ?></td>
      <td> <img src="<?php echo e(asset('team-image/'.$t->image)); ?>" width="100" height="100"></td>
      <td>

          <button class="btn-success btn-sm edit-button">
            <i class="fas fa-edit"></i>
          </button>&nbsp

          <button class="btn-danger btn-sm delete-button">
            <i class="fas fa-trash-alt"></i>
          </button>

            <div class="edit">
                <form action="/team/update/<?php echo e($t->id); ?>" method="post" class="mb-3 mt-3" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="search mb-3" value="<?php echo e($t->name); ?>" name="name">
                    <input type="text" class="search mb-3" value="<?php echo e($t->nim); ?>" name="nim">
                    <input type="text" class="search mb-3" value="<?php echo e($t->role); ?>" name="role">
                    <label for="imgTeam">Kosongi gambar jika tidak ada perubahan</label>
                    <input type="file" name="image" id="imgTeam">
                    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
                    <button type="button" class="btn-sm btn-primary cancel">Batal</button>
                </form>
            </div>

          <div class="trash">
            <form action="/team/delete/<?php echo e($t->id); ?>" method="post">
              <?php echo method_field('delete'); ?>
              <?php echo csrf_field(); ?>
              <label for="">Apakah anda yakin akan menghapus ini?</label>
              <button type="submit" class="btn-sm btn-danger">Hapus</button>
              <button type="button" class="btn-sm btn-primary cancel">Batal</button>
            </form>
          </div>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <td colspan="4" class="text-center">Data Kosong</td>
    <?php endif; ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kantor\manualBook\resources\views/admin/team.blade.php ENDPATH**/ ?>