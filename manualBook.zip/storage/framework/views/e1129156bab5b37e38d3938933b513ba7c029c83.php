

<?php $__env->startSection('content'); ?>
<span class="title-page">Modul(<?php echo e($part->name); ?>)</span>

<form action="/admin/part" method="post" class="mb-3 mt-3">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($part->id); ?>" name="app_id">
    <input type="text" class="search d-inline w-50" placeholder="Tambah Modul" name="name">
    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
</form>

<table class="table table-striped w-100">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Modul</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $part->part; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($p->id); ?>  </th>
      <td><a href="/admin/sub-part/<?php echo e($p->id); ?>"><?php echo e($p->name); ?></a></td>
      <td>
        <button class="btn-success btn-sm">
          <i class="fas fa-edit"></i>
        </button>&nbsp

        <button class="btn-danger btn-sm delete-button">
          <i class="fas fa-trash-alt"></i>
        </button>

        <div class="trash">
          <form action="/delete/sub-part/<?php echo e($p->id); ?>" method="post">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <label for="">Apakah anda yakin akan menghapus ini?</label>
            <button type="submit" class="btn-sm btn-danger">Hapus</button>
            <button type="button" class="btn-sm btn-primary cancel">Batal</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <td colspan="3" class="text-center">Data Kosong</td>
    <?php endif; ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kantor\manualBook\resources\views/inputPart.blade.php ENDPATH**/ ?>