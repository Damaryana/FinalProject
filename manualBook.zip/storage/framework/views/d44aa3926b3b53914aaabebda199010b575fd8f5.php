<div class="page-title text-center mb-3">Team</div>
<div class="page-body">
    <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bio text-center">
            <img src="<?php echo e(asset('team-image/'.$t->image)); ?>" alt="">
            <span class="name mt-2"><?php echo e($t->name); ?> (<?php echo e($t->nim); ?>)</span>
            <span class="role mt-2"><?php echo e($t->role); ?></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<link rel="stylesheet" href="<?php echo e(asset('css/team.css')); ?>"><?php /**PATH F:\Kantor\manualBook\resources\views/website/teamManual.blade.php ENDPATH**/ ?>