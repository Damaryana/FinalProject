

<?php $__env->startSection('content'); ?>
<span class="title-page">Aplikasi</span>

<form action="/admin" method="post" class="mb-3 mt-3">
    <?php echo csrf_field(); ?>
    <input type="text" class="search d-inline w-50" placeholder="Tambah Aplikasi" name="name">
    <input type="text" class="search w-25" placeholder="versi" name="version">
    <button type="submit" class="add-button d-inline"><i class="fas fa-plus"></i></button>
</form>

<form action="" class="mb-3 mt-3">
    <input type="text" class="search w-75" placeholder="Cari">
    <button type="submit" class="add-button"><i class="fas fa-search"></i></button>
</form>

<table class="table table-striped w-100">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Aplikasi</th>
      <th scope="col">Versi</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <th scope="row"><?php echo e($a->id); ?></th>
      <td><a href="/admin/part/<?php echo e($a->id); ?>"><?php echo e($a->name); ?></a></td>
      <td><?php echo e($a->version); ?></td>
      <td>

          <button class="btn-success btn-sm">
            <i class="fas fa-edit"></i>
          </button>&nbsp

          <button class="btn-danger btn-sm delete-button">
            <i class="fas fa-trash-alt"></i>
          </button>

          <div class="trash">
            <form action="/delete/app/<?php echo e($a->id); ?>" method="post">
              <?php echo method_field('delete'); ?>
              <?php echo csrf_field(); ?>
              <label for="">Apakah anda yakin akan menghapus ini?</label>
              <button type="submit" class="btn-sm btn-danger">Hapus</button>
              <button type="button" class="btn-sm btn-primary cancel">Batal</button>
            </form>
          </div>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <td colspan="3" class="text-center">Data Kosong</td>
    <?php endif; ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Kantor\manualBook\resources\views/inputApp.blade.php ENDPATH**/ ?>